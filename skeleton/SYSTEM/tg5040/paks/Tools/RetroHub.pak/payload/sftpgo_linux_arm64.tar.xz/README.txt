For documentation please take a look here:

https://github.com/drakkan/sftpgo/blob/v2.7.6/README.md
